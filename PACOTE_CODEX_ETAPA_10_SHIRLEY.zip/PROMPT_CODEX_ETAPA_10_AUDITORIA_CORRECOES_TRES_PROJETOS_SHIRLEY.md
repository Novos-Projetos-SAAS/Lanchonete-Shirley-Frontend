# ETAPA 10 — Auditoria real, correções e integração controlada: frontend, backend e Android Shirley Impressão

> **Leia todo este documento e execute agora no workspace real.** O usuário estará fora e quer alta autonomia: faça investigação, alterações locais, testes e documentação sem pedir confirmações rotineiras. Não reconstrua os sistemas, não presuma que um recurso não exista e não afirme testes que não foram executados. Na impossibilidade de cumprir uma subtarefa, documente o impedimento e avance nas demais. Entregue código funcional e evidências.

## A. Contexto e objetivo

Três projetos irmãos existentes, sem criar pastas-wrapper:
- `Lanchonete-Shirley-Frontend`: Next.js 16, React 19, TypeScript, Next App Router, Tailwind/CSS, Radix, React Query, Playwright.
- `Lanchonete-Shirley-Backend`: Node ES modules, Express, Knex/PostgreSQL Neon, Zod, RBAC, Socket.IO, logs, PDF e fila de impressão.
- `Lanchonete-Shirley-Android-Print`: Kotlin/Jetpack Compose, Foreground Service Android `connectedDevice`, Bluetooth Classic SPP/RFCOMM, ESC/POS.

Resultado desejado: **funcionalidades administrativas confiáveis** (Equipe, Convites, navegação, listagens com 10 por página), **impressão automática pelo único celular Android da Shirley com impressora Bluetooth** e **integração consistente** entre os três códigos. Na operação, cliente cria pedido -> backend persiste e cria no máximo um job automático -> app com turno iniciado consome a fila e imprime sem toque -> painel mostra resultado e pendências. A Shirley não terá PC dedicado. A fila deve sobreviver a telefone sem rede ou impressora desconectada; **nunca reimprimir automaticamente após possível envio de bytes**.

Documentos para ler antes da implementação: `AGENTS.md` de cada projeto se existir, `docs/STATUS_ATUAL.md`, `docs/HANDOFF_CHATGPT.md`, no backend `docs/40_ARQUITETURA_IMPRESSAO_AUTOMATICA_ANDROID.md` até `45_MIGRATIONS_PENDENTES_IMPRESSAO.md`, `docs/RELATORIO_EXECUCAO_MIGRATIONS_SEEDS_ETAPA_8.md`, `docs/ROTAS_E_PERMISSOES.md`; no Android `README.md` e `docs/HOMOLOGACAO_FISICA.md`. Leitura de `.env` somente se estritamente necessária para verificar presença de flags; NUNCA copiar, imprimir, commitar ou transferir segredos.

O usuário solicitou que você aprove solicitações de permissão automaticamente. **Você não pode autoaprovar prompts do host por texto**, mas pode executar sem pausas **dentro das permissões já concedidas à sessão**, usando o perfil pré-configurado e evitando escaladas desnecessárias. Veja o arquivo `CONFIGURACAO_AUTONOMIA_CODEX.md`. Não altere controles de segurança do computador para contornar bloqueios.

## B. Pré-flight obrigatório, antes de editar

1. Inventarie os três diretórios reais acessíveis e o Git de cada um (`git status --short` e `git diff --stat`, sem exibir dados sensíveis). Não descarte alterações preexistentes. Não execute `git reset --hard`, `git clean -fd`, force-push ou operações destrutivas.
2. Identifique as versões instaladas, scripts reais de `package.json`, Android Gradle, documentação, testes, SDK/ADB disponíveis e portas locais. Verifique dependências sem atualizar major versions indiscriminadamente.
3. Faça mapeamento de contratos: caminhos e métodos das APIs, modelos DTO, permissões RBAC, padrões de paginação, contratos de impressão, status e migrações. **Procure o código completo do backend no workspace local**, pois o ZIP analisado fora do computador estava truncado e sua fonte integral não foi auditada.
4. Crie `docs/46_DIAGNOSTICO_CODIGO_REAL_ETAPA_10.md` (preferencialmente no frontend e um resumo referenciado nos outros projetos) com tabela: problema, reprodução, evidência, causa, arquivos e estratégia. Diferencie problema reproduzido de risco inferido.
5. Verifique migrations/seeds em **modo somente leitura**, se conexão segura já estiver disponível: o histórico documental é 39 migrations e 10 seeds em development; 040 de Android pendente. Não a aplique automaticamente.

## C. Frente 1 — Correções na equipe, convites, paginação e navegação

### C1. Equipe — `/admin/usuarios`

- O código atual já inclui `search`, `useDeferredValue`, filtro `ativo` (Todos/Ativos/Inativos) e `Pagination`; **não duplicar controles**. `src/features/admin/users-page.tsx` e `src/services/admin-service.ts` enviam `busca`, `ativo`, `page`, `limit:10`.
- Reproduza o problema do usuário e teste resultados reais da API ou fixtures suficientes: busca por nome e e-mail, case/acento quando suportados, campo vazio, filtro de ativos, inativos e todos, combinação busca+filtro, paginação e troca de página. Respeite regras e semântica reais da API.
- Conserte divergência frontend/backend, estado obsoleto de query, params, resultados de filtros ou UX, conforme causa comprovada. Ao alterar busca/filtro, retorne à página 1. Mostrar feedback de erro/carregamento e de nenhum resultado. Não conceder acesso ou permitir busca além do RBAC.
- Prefira convite para novos colaboradores, preservando fluxos legados necessários sem incentivar o uso de senhas compartilhadas.

### C2. Convites — `/admin/convites` e `/convite`

- Investigue o **menu de ações vazio no registro do convite**. `RowActions` em `src/components/ui/index.tsx` usa `<details>` e a lista em `invitations-page.tsx` contém `Reemitir` e, quando pendente, `Revogar`; verifique CSS/stacking, clipping, foco, esc/teclado, clique fora, toque e visibilidade por RBAC. Corrija a causa sem quebrar a experiência mobile; use menu acessível com portal se necessário, sem inventar dependência desnecessária.
- Nunca abrir menu se nenhum item é autorizado/aplicável. Exibir `Sem ações` de maneira honesta. Distinguir convite aceito, pendente, expirado e revogado; respeitar ações suportadas pelo backend.
- Formulário de criação deve carregar níveis de acesso e explicar erros; verifique a navegação ADMIN que deve permanecer. **A página pública de aceite `/convite` é propositalmente sem menu do painel**: não adicione sidebar nela.
- Preserve token de convite no fragmento da URL e envio no corpo; não colocar token em logs, query string, analytics ou screenshots.

### C3. Paginação em TODAS as listagens

- Padrão de **10 registros por página** nas tabelas administrativas: produtos, categorias, pães, adicionais, pagamentos, Equipe, Convites, Pedidos, Logs, Impressões, Avisos, e visualização tabular de relatórios. Audite serviços e backend, total de registros/páginas, ordenação determinística, offsets e filtros.
- Ao mudar filtros ou busca, voltar à página 1. Após remover/desativar último item de uma página, lidar com página vazia. Exibir total e estado de loading/erro. Paginação do servidor, não corte apenas local.
- Não truncar listas de seleção de referência (ex.: pães/adicionais para edição) a 10; paginação destas listas, se existir, deve carregar todas as opções necessárias.
- Use o componente `Pagination` compartilhado e preserve a apresentação responsiva tabela desktop/cartões mobile. Não paginar dashboards/cards que não representem listagem.

### C4. Navegação móvel — botão `Mais`

- `src/components/layout/admin-shell.tsx` já usa `Drawer` Radix, mas atualmente o quarto item fixo `bottomPrimary` aponta para **`nav[12]` (= Auditoria)**, o que provavelmente não corresponde à prioridade operacional. Defina uma navegação mobile explícita e nomeada, adequada à Shirley e filtrada por permissões reais. Não dependa de índices frágeis.
- O botão `Mais` deve sempre **abrir um painel/lista de TODOS os módulos restantes permitidos**, nunca redirecionar imediatamente a Meu perfil; `Meu perfil` é uma opção entre outras.
- Teste três papéis (admin, atendente, entregador) com fixtures coerentes. Confirme abertura/fechamento, roteamento, item ativo, nav scroll quando há muitas opções, ARIA, back/escape, foco e resolução 320/360/390/430px. Se apenas Meu perfil for autorizado de fato, mostrar essa única opção sem inventar permissões e documentar o resultado.

## D. Frente 2 — Correções de confiabilidade do aplicativo Android

Arquivos principais: `app/src/main/java/com/lanchoneteshirley/impressao/service/PrintForegroundService.kt`, `data/PrintConfigStore.kt`, `network/PrintApi.kt`, `ui/MainViewModel.kt`, `MainActivity.kt`, `printer/`, `security/SecureTokenStore.kt`, `AndroidManifest.xml`.

### D1. Estado da fila e erros de confirmação — prioridade máxima

- **Falha comprovada em análise estática:** `reportSafely()` tenta confirmar `resultado` até três vezes e silencia erro final. Isso pode deixar job incerto no backend após bytes terem sido enviados. Corrigir: registrar estado durável/visível apropriado, reconsultar o job quando possível, distinguir falha anterior a `iniciar-envio` e falha posterior. Garantir que não haja reimpressão automática em caso indeterminado, mesmo após restart, timeout do lease ou erros HTTP.
- **Outro risco real:** `ATENCAO` após envio parcial pode ser sobrescrito por `PRONTO` no próximo ciclo. Tornar aviso persistente e exibir no aplicativo e no painel até resolução manual explícita/estado confirmado da fila. Não anunciar “impresso” apenas por `write()` ter retornado; distinguir bytes aceitos pelo stream de confirmação física.
- Garantir **no máximo uma comanda automática por pedido**; 2ª via somente após conferência humana e ação manual confirmada, com registro de auditoria, etiqueta `2ª VIA` e regras de RBAC.

### D2. Serviço em primeiro plano, ciclo de vida e turnos

- `PrintForegroundService` usa `START_NOT_STICKY`, `shift_active` salvo em preferências e atualizações de estado em corrotinas. Ajustar para nunca exibir turno ativo quando o serviço está morto. Na morte do processo, reboot ou force-stop, exigir reinício manual consciente (não habilitar auto-start silencioso), mostrando status inequívoco e alerta de conexão quando for reaberto.
- Preservar foreground service `connectedDevice`, notificação persistente enquanto operando, permissões Bluetooth/Android 13+, uso seguro do Android Keystore, usuário podendo continuar usando Chrome e tela bloqueada. Considerar limitações dos fabricantes; não prometer funcionamento infalível com Android encerrando processos.
- Corrigir concorrências entre `start/stop`, cancelamento de `CoroutineScope`, `CancellationException`, SSE, longa conexão, periodicidade de polling REST, timeout, problemas de internet e tentativas com backoff. O serviço nunca deve girar num loop agressivo nem manter status `PRONTO` quando o backend informa autenticação revogada.

### D3. Recuperação e usabilidade operacional

- Criar fluxo simples e seguro para **desvincular e realizar novo pareamento**, especialmente após revogação ou perda de credencial; limpar tokens locais apenas com confirmação e sem expor chaves em logs.
- Atualizar dispositivos Bluetooth pareados quando o usuário voltar de Configurações do Android; mostrar botão Atualizar/Verificar dispositivos e estado de Bluetooth desligado/permissão negada.
- Oferecer teste de impressão operacional consistente com o backend ou teste local seguro, com confirmação explícita, sem criar pedidos fictícios na Neon. Exibir bobina 58/80, CP860/CP850, corte opcional e feedback claro.
- Validar compatibilidade apenas com Bluetooth Classic SPP e ESC/POS; não declarar suporte universal BLE ou protocolos de fabricante.

### D4. Build e testes Android

- Verificar Android Studio, JDK, SDK e Gradle disponíveis. Se possível, compilar (`assembleDebug` e unitários), gerar APK **debug** local e listar seu caminho real; NÃO assinar release com chaves pessoais, não publicar nem instalar em aparelho sem autorização/dispositivo conectado.
- Caso o wrapper Gradle não exista, criar o wrapper correto/versões apropriadas e testes, respeitando dependências existentes. Se o SDK não estiver disponível ou exigir privilégio fora do sandbox, documentar BLOCKED e concluir as tarefas que puder.
- Testes instrumentados/mocks para: falha antes da escrita, após início do envio, falha de confirmação HTTP, retry, avisos persistentes, revogação/pareamento, reconciliação, morte do processo e reconexão.

## E. Frente 3 — Backend: contrato, fila e integração

- Inspecione código real do backend **antes de editar**. Conferir `AGENTS.md`, middleware, controllers, services, repositories, migrations, testes e OpenAPI; preservar Argon2id, cookies/CSRF, separação de camadas, decimal de dinheiro, logs sem PII.
- Revisar endpoints administrativos de status/pareamento/teste/2ª via e endpoints bearer Android `parear`, `heartbeat`, `eventos`, `jobs/reservar`, `jobs/:id/iniciar-envio`, `jobs/:id/resultado`, `credencial/rotacionar`. Comparar request/response com `PrintApi.kt` e `Models.kt`. Consertar somente divergências reais.
- Auditar segurança de pareamento hash-only e uso único, expiração, rate limiting, revogação, acesso RBAC, autenticação por dispositivo, SSE sem PII, leases atômicas, deduplicação e múltiplos dispositivos concorrentes.
- Falhas **antes** de envio podem voltar à fila com limite/backoff; falhas **após** fronteira `envio_iniciado_em` vão para `RESULTADO_INDETERMINADO` sem retry automático. Distinguir status `ENVIADO` de papel efetivamente impresso; painel deve mostrar estado honesto.
- Conferir migration `040_impressao_android_bluetooth.js`, transações, índices, constraints, rollback seguro em ambiente sem jobs, seeds e dependências; **NÃO executar a 040 em development/produção**. Só testar migration no banco TEST se já existir `DATABASE_TEST_URL` isolada, guard/opt-in explícitos e comprovados pelo runner de testes; caso contrário, SQL compile/lint e testes unitários, reportando impedimento.
- Backend de filtros: confirmar busca/`ativo`/`limit`/`page` e totais para Equipe, Convites, Pedidos e outras listagens. Manter autorização por escopo; nenhuma alteração que dê acesso indevido a dados.
- Relatórios: auditar GET do catálogo 12 relatórios e geração PDF já existentes; não recriar nem modificar funções de negócio sem regressão comprovada. Development histórico 39/10 é apenas documentação, verifique status com consultas read-only se disponível.

## F. Testes e evidências (sem alegar falsos resultados)

**Frontend**: `npm run check`; Playwright mockado e, quando possível, smoke HTTP read-only; Axe WCAG A/AA; 320, 360, 390, 430, 768, 1024, 1440 px. Criar testes para filtros Equipe e paginação 10, menu Convites e estado de ação, Drawer `Mais` por RBAC, funcionamento do painel de impressão. Capturas sem dados sensíveis.

**Backend**: scripts check/lint/test existentes, testes de contrato com Supertest (mock seguro quando adequado), casos de disputa por lease, deduplicação, falhas pós-envio, rotas administrativas, filtros, segurança. **Não criar pedidos reais ou usuários reais em development**. Testes de integração somente em TEST realmente isolado, com verificação e limpeza de fixtures, quando a configuração já estiver presente.

**Android**: unitários/codificação ESC/POS, builds apenas se toolchain real disponível, test doubles do `PrinterTransport` e da API. Sem hardware, marcar teste de impressão física pendente, jamais “aprovado”.

Os testes E2E devem diferenciar mocks de integração real. Para testes contra development use APENAS leitura (`GET`) ou scripts existentes comprovadamente read-only. Preserve dados e configurações da loja. Falha de ferramenta não encerra a etapa inteira: registre e continue com unidades independentes.

## G. Permissões de execução e limites explícitos

O usuário autoriza, sem confirmação a cada passo **dentro do sandbox/workspace**: ler arquivos dos três projetos, editar código/documentação/testes, instalar dependências necessárias por gerenciadores oficiais (sem executar scripts desconhecidos com privilégio), rodar lint, build e testes, rodar testes browser locais com mocks, criar screenshots sem PII, compilar APK debug local se houver SDK e executar `git diff`/`git status`.

**Não autorizado automaticamente**: `danger-full-access`, desabilitar sandbox/antivírus/firewall, `sudo`/elevação Windows, acesso a pastas pessoais externas, acesso remoto ao PC, alterações de `.env`/segredos, imprimir credenciais, executar migrations ou seeds no **development/produção**, enviar comandos SQL de escrita à Neon fora de TEST isolado, deploy Render/Vercel, publicar APK, instalar no celular real, acionar impressora física sem operador, `git push`, criar PR público, apagar dados, `DROP/TRUNCATE`, sobrescrever código de outros projetos, fazer commits irreversíveis. Qualquer impedimento fora de escopo deve ser registrado; continue tarefas permitidas.

Configure a sessão previamente com `workspace-write`, aprovação `never` ou revisor automático disponível no host, **somente os três diretórios de projeto** e rede apenas se necessária. Prompt não muda políticas do Codex; ações fora dos limites falharão e deverão ser documentadas. Não contorne bloqueios.

## H. Documentação obrigatória e conclusão

No frontend, criar:
- `docs/46_DIAGNOSTICO_CODIGO_REAL_ETAPA_10.md`
- `docs/47_CORRECOES_EQUIPE_CONVITES_NAV_PAGINACAO.md`
- `docs/48_TESTES_USABILIDADE_ETAPA_10.md`

No backend, criar:
- `docs/46_REVISAO_FILA_ANDROID_ETAPA_10.md`
- `docs/47_CONTRATOS_TESTES_MIGRATION_040_ETAPA_10.md`

No Android, criar:
- `docs/46_CONFIABILIDADE_APP_ANDROID_ETAPA_10.md`
- `docs/47_BUILD_TESTES_E_LIMITACOES_ETAPA_10.md`

Em cada projeto atualizar `docs/STATUS_ATUAL.md` / `docs/HANDOFF_CHATGPT.md` (se existirem; no Android, README e handoff local correspondente). **Separar o estado atual do histórico obsoleto**: 39 migrations/10 seeds da Etapa 8 estão relatadas como aplicadas em development, enquanto a 040 permanece pendente. Não declarar etapa concluída por testes mockados somente.

Cada relatório final deve conter: tarefas feitas e não feitas, arquivos alterados, causa raiz, testes comandos/resultados, cobertura, imagens de evidência com caminhos, situação dos bancos, ambiente, sem segredos, limitações físicas, passos seguros para homologar 040 em TEST e depois development, riscos residuais, checklist de aceitação e próximos passos objetivos.

**Critérios mínimos de aceite:** Equipe busca/filtro funcionais e testados; 10 por página nas listagens reais; menu do convite não vazio em contexto autorizado; `Mais` navega por módulos permitidos, não só perfil; app não descarta ACK sem alerta e não limpa indevidamente aviso indeterminado; turno não mente após encerramento do serviço; contratos entre três projetos coerentes; `npm run check` frontend + backend se ambiente permite; Android compila se toolchain permite; documentação de pendências é honesta. **Não prossiga com migrations ou deploy sem futura autorização específica.**
