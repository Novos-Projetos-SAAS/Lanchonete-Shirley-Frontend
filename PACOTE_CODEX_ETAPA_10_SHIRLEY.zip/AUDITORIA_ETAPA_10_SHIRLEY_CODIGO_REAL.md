# Auditoria estática de código — Lanchonete Shirley — Etapa 10

Data da revisão: 31/10/2026. Base: ZIPs do frontend e aplicativo Android e conteúdo recuperável do ZIP novo do backend, juntamente com documentação compartilhada. **Esta é auditoria estática; não executei build, testes de integração, migrações, deploy nem testes físicos.**

## Limitação do backend recebido

- `Lanchonete-Shirley-Backend - Copia(1).zip` contém assinaturas de arquivos ZIP, mas **está truncado e sem diretório central**. `zipfile` e `unzip` não conseguem abri-lo como arquivo completo. O tamanho recebido é 50.032.640 bytes.
- Foi possível recuperar documentação e arquivos iniciais por cabeçalhos ZIP locais; **não foi possível auditar integralmente o código atual do backend**, que aparece após uma grande árvore `.git`/`node_modules` na compactação.
- O ZIP inclui um arquivo `.env` (seu conteúdo não foi exibido nem copiado para o relatório). Não reencaminhar esse arquivo nem salvá-lo no repositório. Exportar novamente com exclusão de `.env`, `.git`, `node_modules`, cobertura e artefatos compilados. Codex no computador deve ler **o workspace real**, não confiar neste arquivo incompleto.
- Documento recuperado `docs/RELATORIO_EXECUCAO_MIGRATIONS_SEEDS_ETAPA_8.md` registra development com **39 migrations, 10 seeds e funções dos 12 relatórios**; é resultado relatado no documento, não validado novamente por esta auditoria. `docs/45_MIGRATIONS_PENDENTES_IMPRESSAO.md` aponta a migration 040 ainda pendente.

## Frontend — fatos observados diretamente

### Equipe
- `src/features/admin/users-page.tsx` **já tem** busca por nome/e-mail (`search`/`useDeferredValue`), filtro Todos/Ativos/Inativos, reset de página para 1, `Pagination` e listagem por `adminService.listResource`.
- `src/services/admin-service.ts` preenche `page:1, limit:10` por padrão. **Não recriar** o que já existe. Reproduzir o defeito reportado, conferir se API usa `busca`/`ativo`/`limit` corretamente e se a tela exibe estado correto nos diferentes perfis de usuário.
- Atenção à precedência de `ativo === false` e relação com nível de acesso, `queryKey`, respostas de paginação, invalidação e reset dos filtros.

### Convites
- `src/features/admin/invitations-page.tsx` já possui formulário de criação, consulta de níveis de acesso e tabela de convites; as ações `Reemitir`/`Revogar` ficam em `RowActions`.
- `RowActions` em `src/components/ui/index.tsx` usa `<details><summary>...`; seu menu é absoluto em `.row-actions__menu` (`src/app/globals.css`). Investigar recortes, empilhamento, fechamento, menu aberto vazio e RBAC por ação; **não declarar causa sem reproduzir no navegador**.
- Tela pública de aceite `/convite` deve continuar sem navegação administrativa; a tela **administrativa** `/admin/convites` precisa manter o menu normal.
- Convites aceitos mostram texto `Sem ações`; outros estados exibem Reemitir quando permitido. Garantir que menu não abra se não houver ação autorizada e que o usuário entenda por quê.

### Navegação mobile
- `src/components/layout/admin-shell.tsx` possui Drawer Radix em `Mais`, mas `bottomPrimary = [nav[0], nav[1], nav[2], nav[12]]`: o quarto atalho é **Auditoria** na lista atual, o que pode ser inadequado para o uso mobile da lanchonete.
- A lista de `Mais` é calculada por RBAC. Investigar o relato de que só aparece `Meu perfil`: pode ser RBAC, composição dos atalhos, navegação ou falha visual, sem assumir causa única. Testar administrador, atendente e entregador, abrindo o Drawer e clicando em itens; menu vazio deve informar falta de opções, não inventar permissões.

### Paginação
- `adminService.listResource`, `orders`, `invitations`, `notifications`, `printJobs` usam `limit:10`; `ResponsiveTable` renderiza os itens recebidos e `Pagination` exibe navegação.
- Auditar TODAS as listagens, inclusive logs, usuários, catálogos, convites, pedidos, impressões, notificações e prévia de relatórios. Checar contagem vinda do backend, páginas >1, estado vazio, filtros, retorno à primeira página. Não aplicar paginação artificial somente no cliente se houver servidor paginado.
- **Exceção intencional:** opções internas de seletores (pães/adicionais) podem carregar >10 para não perder opções. Não limitar essas consultas de referência a 10.

### Impressão e relatórios
- `src/features/printing/printing-page.tsx` já contém método ativo, dispositivos, fila paginada, pareamento, revogação, teste pelo painel e 2ª via. Evitar duplicar recursos; testar estados reais de erro, desconexão e migration ausente.
- O relatório frontend usa contratos de relatório dinâmico, PDF autenticado e prévia paginada; documentos da Etapa 8 indicam 39/10 já aplicadas. Testar sem escrita em development e sem gerar pedidos reais.

## Android — defeitos e riscos conferidos no código

1. **Alta — Falha silenciosa na confirmação ao backend.** `app/src/main/java/com/lanchoneteshirley/impressao/service/PrintForegroundService.kt`, `reportSafely` tenta 3 vezes, mas retorna sem registrar um erro durável após falha final. Uma escrita Bluetooth pode ter ocorrido e o servidor ficar sem conclusão. Exigir alerta persistente e reconciliação conservadora, sem reimpressão automática pós-fronteira.
2. **Alta — Aviso indeterminado sobrescrito.** `printJob` define `ATENCAO` em falha após `iniciar-envio`, mas `runShift` define `PRONTO` no ciclo subsequente. O aviso crítico precisa permanecer até conferência/tratamento explícito; a fila do servidor é fonte de verdade.
3. **Alta — Turno salvo ≠ serviço realmente vivo.** `PrintConfigStore.setRuntime(true, ...)` e `PrintForegroundService.start` escrevem `shift_active`; `START_NOT_STICKY` e `onDestroy` não promovem necessariamente reconciliação de estado quando o sistema encerra o serviço. Mostrar estado real e heartbeat, com reinício manual explícito após morte/reboot, sem impressão silenciosa.
4. **Média/alta — Recuperação de credencial/pareamento.** Existe `PrintConfigStore.clearPairing()` mas não identifiquei fluxo completo na UI/ViewModel para desvincular e parear novamente após revogação; não gerar perda irreversível de acesso.
5. **Média — Atualização de dispositivos pareados.** `MainActivity.kt` calcula dispositivos pareados com `remember(permissionTick, bluetoothGranted)`, o que não garante nova consulta ao retornar das configurações do Android.
6. **Média — Diagnóstico/teste no celular.** O painel web tem impressão de teste, mas não há teste direto inequívoco no aplicativo Android. Avaliar botão seguro de teste local e orientação para bobina, encoding e corte; jamais imprimir uma comanda real fictícia automaticamente em produção.
7. **Média — Timeout e shutdown.** Auditar SSE, reabertura após desconexão, cancelamento de corrotinas/`CancellationException`, heartbeat, `stopShift` e reconciliação REST de 15 s.
8. **Compilação:** o projeto não acompanha wrapper Gradle completo no ZIP. Validar no ambiente com Android Studio/SDK disponível; caso indisponível, documentar BLOCKED e não declarar APK compilado ou hardware aprovado.

## Back-end — itens a verificar no código real no computador

- Compatibilidade e segurança dos endpoints `/api/v1/agente-impressao/android/*` com `PrintApi.kt` e `Models.kt` (método, path, envelope, status HTTP, lease, tokens, erros, idempotência, SSE e reconciliação).
- Migration `040_impressao_android_bluetooth.js`: revisar e testar apenas em PostgreSQL TEST isolado e explicitamente configurado; não aplicar em development/prod automaticamente.
- Garantir que status `RESULTADO_INDETERMINADO` jamais seja reimpresso automaticamente, não duplicar jobs e marcar 2ª via somente por confirmação humana.
- Verificar endpoints de listagem paginada/filtros e papéis RBAC, sem alterar o contrato por suposição.
- Cobertura de testes isolados sobre fila, dois dispositivos simultâneos, lease vencida, impressão antes/depois do envio e cancelamento/reconexão.

## O que não foi provado nesta análise

- Compilação do Android; impressão física Bluetooth; execução integrada com API real; execução de migrations 040; defeito de `Mais` em navegador real; filtro da equipe com dados concretos; conformidade dos resultados da API de listagens; presença de dados corretos no frontend autenticado.

## Priorização

1. Segurança da fila e alertas/estados reais Android (sem duplicação de papel).
2. Correções funcionais de Equipe/Convites/Mais/Paginação, mediante reprodução.
3. Testes dos contratos e smoke testes de backend/frontend, sem escritas em development.
4. Preparação da migration 040 e testes apenas em TEST isolado, se já habilitado.
5. Documentação e handoff; homologação física em outro momento com aparelho e impressora.
