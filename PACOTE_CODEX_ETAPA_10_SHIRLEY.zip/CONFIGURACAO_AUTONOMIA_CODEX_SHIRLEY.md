# Codex — autonomia ao trabalhar enquanto o usuário estiver fora

O Codex **não consegue aceitar o próprio diálogo de aprovação por um comando escrito no prompt**. A escolha de permissões é feita no aplicativo/extensão/CLI **antes** da tarefa. A meta é autonomia para editar e testar três projetos, não liberar a máquina inteira ou o banco de produção.

## Configuração indicada (Codex CLI / config.toml)

```toml
approval_policy = "never"
sandbox_mode = "workspace-write"

[sandbox_workspace_write]
network_access = true
```

**Atenção:** `never` não burla o sandbox; operações fora dos diretórios autorizados poderão ser recusadas. A rede deve ficar habilitada somente se for preciso instalar dependências ou consultar documentação. A configuração também pode ser escolhida por `/permissions` ou no seletor de permissões da extensão, se existir. A revisão automática (`approvals_reviewer = "auto_review"`) é outra possibilidade quando disponível, com aprovação apenas de solicitações elegíveis e dentro dos limites do host.

Abra no VS Code **somente a pasta-pai dos três repositórios** (ou um workspace multi-root, garantindo escrita nos três diretórios). Evite abrir `C:\Users` ou o disco inteiro. Se os três projetos forem irmãos de uma mesma pasta dedicada, iniciar o Codex nessa pasta delimita melhor o trabalho. O backend já possuía `.codex/config.toml` com `approval_policy="never"` e `sandbox_mode="workspace-write"`; o Codex deve confirmar a configuração **ativa** de sua sessão, sem alterá-la às cegas.

Se estiver usando a CLI e sua instalação oferecer as flags, `--sandbox workspace-write --ask-for-approval never` aplica esses ajustes à sessão. Não usar `--dangerously-bypass-approvals-and-sandbox` nem `danger-full-access` apenas por conveniência.

O prompt mestre autoriza edição, testes, builds, dependências e artefatos **nos projetos**. Não autoriza deploy, push, migrations em development/produção, segredos, exclusões destrutivas, instalação APK em celular nem impressão real sem operador presente.

Antes de sair: mantenha o computador ligado, suspenda o modo de suspensão do Windows durante a tarefa conforme sua preferência, deixe o Codex iniciado com o workspace correto e confirme que o perfil de permissões está ativo. Não há garantia de execução se o PC suspender ou o host exigir login/permissão externa.

Comando curto para colar no Codex após deixar o pacote na pasta-pai:

> Localize `PACOTE_CODEX_ETAPA_10_SHIRLEY.zip` na pasta-pai dos três projetos, extraia APENAS os Markdown em pasta temporária segura e leia `LEIA_PRIMEIRO.md`, `AUDITORIA_ETAPA_10_SHIRLEY_CODIGO_REAL.md`, `CONFIGURACAO_AUTONOMIA_CODEX_SHIRLEY.md` e integralmente `PROMPT_CODEX_ETAPA_10_AUDITORIA_CORRECOES_TRES_PROJETOS_SHIRLEY.md`. Execute a Etapa 10 nos três projetos existentes. Trabalhe autonomamente dentro do sandbox configurado, sem solicitar aprovações rotineiras. Não altere bancos de desenvolvimento/produção, segredos ou deploy; continue outras tarefas se houver bloqueio e atualize handoffs e relatórios de testes. Não copie o ZIP nem a pasta temporária para `public/`, Git ou deploy.
