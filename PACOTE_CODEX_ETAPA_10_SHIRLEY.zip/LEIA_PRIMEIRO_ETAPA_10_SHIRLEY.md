# LEIA PRIMEIRO — Pacote Codex Etapa 10 Shirley

Conteúdo do pacote:

1. `AUDITORIA_ETAPA_10_SHIRLEY_CODIGO_REAL.md`: achados objetivos dos arquivos recebidos, limitações de leitura e prioridades.
2. `PROMPT_CODEX_ETAPA_10_AUDITORIA_CORRECOES_TRES_PROJETOS_SHIRLEY.md`: tarefa mestre para FRONTEND, BACKEND e ANDROID.
3. `CONFIGURACAO_AUTONOMIA_CODEX_SHIRLEY.md`: configuração de autonomia e limites.

**Como usar:** coloque este ZIP na **pasta-pai dos três projetos irmãos**, não dentro do diretório `public`, e inicie o Codex com esta pasta como workspace. Ordene que ele extraia os três Markdown para pasta temporária segura, leia completamente e implemente as correções **no código existente**. Não recrie os projetos.

**Observação sobre origem dos achados:** frontend e Android recebidos foram abertos e inspecionados; o ZIP novo do backend estava truncado. O Codex deverá auditar o backend diretamente pelo workspace real antes de qualquer modificação. Nenhum segredo ou `.env` acompanha este pacote.

**Não executar automaticamente:** migrations 040 em development/produção, deploy, commits/push, acesso fora de workspace, alteração de credenciais, pedidos reais ou impressão física sem acompanhamento.
