# Prompt direto para IA geradora de imagens — Shirley Lanches

**Anexe as duas imagens de referência junto a este prompt.** Substitua os trechos entre colchetes pelos ingredientes e pelo nome verificados no cadastro antes de gerar cada produto.

> Utilize as **duas imagens anexadas como referências visuais principais**, observando cuidadosamente o tipo de fotografia, o ângulo da câmera, a iluminação, o enquadramento, a proporção da comida, a textura dos ingredientes e a profundidade de campo. Crie uma **nova fotografia comercial de alimento**, e não uma cópia, montagem ou recorte das referências.
>
> O produto fotografado é **[NOME EXATO DO PRODUTO]**, preparado **somente** com **[INGREDIENTES DO CADASTRO]** e apresentado com **[TIPO DE PÃO OU RECIPIENTE CORRETO]**. Retrate o produto com fidelidade gastronômica: pão com textura natural, proteínas corretamente grelhadas, vegetais frescos quando previstos, queijos e molhos em quantidades críveis. O resultado deve parecer um alimento real, feito na hora por uma lanchonete artesanal — apetitoso, porém sem exageros, sem ingredientes flutuantes e sem camadas impossíveis.
>
> Adote uma estética **editorial gastronômica premium, sóbria e consistente**: iluminação lateral suave, sombras físicas naturais, contraste moderado, cores fiéis aos alimentos, fundo discreto e neutro compatível com as referências, foco nítido no produto e desfoque delicado no fundo. Enquadramento de três quartos ou o ângulo predominante nas referências, com distância e escala consistentes entre produtos. O alimento deve ocupar cerca de 75% do quadro, permanecer inteiramente visível e ter margem de segurança para recorte em cards. Fotografia profissional realista, não ilustração nem render 3D.
>
> **Não acrescente ingredientes não mencionados.** Não colocar texto, etiquetas, preços, slogans, brasões, embalagens com marcas inventadas, mãos ou pessoas. Não usar luzes neon, fundo amarelo forte, saturação artificial, fumaça excessiva, queijo exagerado, brilho plástico ou excesso de adereços. **Uma única fotografia em proporção 1:1, 1024×1024 ou maior, sem marca d'água.**

## Como utilizar

1. Envie as duas referências juntamente com o prompt.
2. Faça **uma geração por produto** usando nome/ingredientes reais. Não envie apenas uma lista de nomes pedindo imagens em lote sem verificar as descrições.
3. Use o mesmo estilo e referências para todas as fotos, mas diferencie visualmente os ingredientes de X-Bacon, X-Egg, X-Frango, X-Tudo etc.
4. Para porções, mantenha a luz e o fundo, mudando o enquadramento para mostrar o volume. Para bebidas com marca, use fotografias licenciadas/reais, não tente gerar rótulos falsos.
5. Após aprovar, converta para WebP e salve na pasta `public/images/produtos/` do frontend.
