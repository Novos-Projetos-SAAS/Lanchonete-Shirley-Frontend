# Lanchonete Shirley — Como usar os prompts

Arquivos deste pacote:

1. **PROMPT_DIRETO_IA_FOTOS_PRODUTOS_SHIRLEY.md** — prompt curto, mas detalhado, para enviar diretamente à IA de geração de imagens, anexando as duas referências visuais.
2. **PROMPT_CODEX_ETAPA_7C_IMAGENS_PRODUTOS_SHIRLEY.md** — implementação completa no Codex: inspecionar referências e cardápio, gerar fotos, otimizar WebP, salvar em `public/images/produtos/`, integrar sem mexer em dados comerciais, testar e documentar.
3. **PROMPT_CODEX_AJUSTES_DASHBOARD_SHIRLEY.md** — complemento do pedido anterior: header das tabelas com contraste sutil, indicação de loja aberta/fechada, gap entre inputs e seleção de retirada/entrega, sidebar neutra com destaque, testes.

**IMPORTANTE:** as duas imagens de referência enviadas ao ChatGPT não são copiadas automaticamente para a pasta do Codex. Anexe-as à tarefa do Codex ou copie-as para `referencias_visuais/fotografia_produtos/` com nomes `referencia_01` e `referencia_02` mantendo as extensões originais.

Rodar cada prompt na raiz atual do frontend. Não executar migrations/seeds nem gravar diretamente no Neon para gerar imagens. Não confundir fotografias DEMO com produtos reais da cliente.
