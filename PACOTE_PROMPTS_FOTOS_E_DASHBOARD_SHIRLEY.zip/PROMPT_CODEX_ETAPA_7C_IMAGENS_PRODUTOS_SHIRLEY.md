# ETAPA 7C — Fotografias de produtos com IA para a Lanchonete Shirley

> **Execute no frontend Next.js existente, na raiz atual.** Não crie outro projeto, não refaça a interface, não edite migrations ou seeds e não acesse diretamente o PostgreSQL. O objetivo é **gerar, selecionar, otimizar e integrar imagens demonstrativas de produtos**, respeitando o visual sóbrio do redesign e o cardápio realmente cadastrado.
>
> **Material obrigatório:** duas imagens de referência fornecidas pelo usuário nesta conversa. Elas devem ser disponibilizadas ao Codex como anexos da tarefa ou copiadas pelo usuário para `referencias_visuais/fotografia_produtos/referencia_01.*` e `referencia_02.*`. **Abra e inspecione as duas imagens antes de qualquer geração**. Se não estiverem acessíveis, registre esse impedimento em `docs/IMAGENS_PRODUTOS.md` e não afirme que seguiu referências que não viu; use o briefing abaixo como alternativa provisória.
>
> As referências definem **linguagem fotográfica, luz, composição, distância, contraste e realismo**; não são licença para copiar fotos, marcas, textos ou a identidade de outro estabelecimento. **Nenhum recorte das imagens originais pode substituir uma imagem nova gerada.**

## 1. Descobrir as ferramentas e as referências

1. Inspecione as skills disponíveis no ambiente, leia as instruções pertinentes e use **`imagegen` ou a skill real de geração de imagens**, se instalada e acessível. Consulte `frontend-design`/`ui-ux-pro-max` para compatibilidade estética, se disponíveis. Não invente uma skill nem finja ter gerado imagens. Se não houver geração de imagens disponível, entregue os prompts finais individualizados e um manifesto de produção; não substitua por imagens encontradas aleatoriamente na internet.
2. Abra as **duas referências** e registre em `docs/IMAGENS_PRODUTOS.md`, sem reproduzir PII: ângulo de câmera, fundo, tipo de luz, cor e textura dos alimentos, enquadramento, proporção do produto no quadro, presença de prato/papel/mesa, sombras, contraste, sensação fotográfica e o que **não** devemos imitar.
3. Verifique o catálogo DEMO efetivo por fontes locais de código/docs ou respostas públicas somente leitura da API. Cada descrição, pão, ingrediente e nome deve ser confirmado antes de escrever o prompt específico. Se houver divergência entre nomes DEMO e o banco, prevalece o catálogo efetivo. Não invente ingredientes para completar uma foto.
4. Faça um inventário de imagens existentes em `public/images/produtos/`, sem sobrescrevê-las automaticamente. Não retire imagens reais já cadastradas.

## 2. Direção criativa — fotografia comercial consistente

**Objetivo:** um catálogo de lanchonete artesanal com fotos convincentes de comida real, apetitosas e discretas, como imagens feitas por um fotógrafo gastronômico para um cardápio digital premium. A qualidade deve ser alta, mas não parecer publicidade artificial ou surreal.

**Linguagem visual unificada a partir das duas referências:**
- O ingrediente principal deve ser a estrela e ocupar aproximadamente **70–82% da área útil**. Fotografia focada na comida, enquadramento consistente entre produtos da mesma categoria; plano médio-fechado e perspectiva realista, evitando lente grande-angular.
- Luz macia lateral/difusa, com leve brilho natural sobre pão, queijo e proteínas; sombras suaves e coerentes. Realçar textura e frescor sem oversharpening, reflexos plásticos ou saturação exagerada.
- Paleta secundária neutra e sofisticada (cinza quente, off-white, grafite suave ou madeira discreta **somente se as referências sustentarem**). Evitar fundos amarelos saturados, neon, vermelho espalhado, efeitos de fogo/fumaça falsa e elementos carnavalescos. A comida pode ser naturalmente colorida.
- Um mesmo padrão de distância, escala, ângulo, balanço de branco, contraste e profundidade de campo para **todos os lanches**. Porções seguem a mesma direção fotográfica, mas com enquadramento que mostra o volume real. Bebidas usam enquadramento mais limpo e iluminação controlada.
- Texturas plausíveis: casca de pão com poros naturais, alface com nervuras reais, queijo derretido coerentemente, bacon com gordura e crocância naturais, proteínas com grelhado sutil. **Sem ingredientes flutuantes, pão deformado, excesso de molho, queijo impossível, alimentos duplicados, plástico ou ilustração.**
- Fotos **sem texto, preços, marcas, logotipos, selos, ícones, bordas, molduras, legendas ou marca d'água**. Não inserir mãos, pessoas ou utensílios desnecessários. Não repetir exatamente a mesma composição e os mesmos ingredientes para todos os lanches.
- Respeite fielmente o tipo de pão e os ingredientes de cada item. Não mostre opcionais (pão francês, bacon, ovo, queijo extra etc.) como ingredientes obrigatórios do produto se eles não forem parte da descrição base; se houver ambiguidade, opte pelo produto base e documente.
- **Não usar imagem de um produto diferente como substituição**, nem representar refrigerantes de marca com logotipo gerado incorretamente. Para produtos de marca, preferir foto real autorizada fornecida pela cliente no futuro; para DEMO, imagens genéricas sem rótulo comercial ou placeholders claramente demonstrativos.

### Prompt-mestre para cada geração (adaptar à referência e ao item)

> Fotografia gastronômica hiper-realista e editorial de **[NOME REAL DO PRODUTO]**, preparado com **[INGREDIENTES REAIS DO CADASTRO, EXATAMENTE]**, servido **[FORMA DE APRESENTAÇÃO CORRESPONDENTE À REFERÊNCIA]**. Manter a **mesma linguagem visual das duas imagens de referência anexadas**: ângulo de câmera, distância, direção de luz, paleta de fundo, profundidade de campo, contraste e escala semelhantes, **sem replicar literalmente a composição**. Comida autêntica e preparada na hora, textura natural, aparência apetitosa e crível, cores realistas, iluminação lateral suave de fotografia comercial, foco nítido nos ingredientes principais, detalhes orgânicos, fundo sem distrações, sombras fisicamente plausíveis. Enquadramento quadrado de catálogo, item inteiro visível com margem segura de corte de 10%, composição centralizada com leve dinamismo, sem tipografia, sem preço, sem logomarca, sem mão, sem pessoa, sem marca d'água. **Não adicionar ingredientes não listados, não substituir o tipo de pão, não exagerar no tamanho, não criar elementos flutuantes ou artificiais.** Output: uma única fotografia de produto de alta qualidade, 1:1.

**Negative constraints a aplicar:** ilustração, desenho 3D, comida plástica, anatomia impossível, ingrediente extra, dupla montagem, queijo infinito, ketchup derramado, fumaça exagerada, fundo promocional, neon, saturação forte, texto, watermark, logotipo, pessoas, mãos, objetos cortados, imagem borrada, deformações, múltiplos produtos acidentais.

## 3. Shot list — construir prompts individualizados, não um prompt genérico repetido

Use a descrição real do backend antes de gerar. Os nomes abaixo correspondem ao catálogo DEMO anteriormente planejado; **verificar se ainda são os produtos atuais**, não assumir lista definitiva.

| Produto | Direção específica para a composição (condicional à descrição real) |
|---|---|
| Hambúrguer Clássico | Sanduíche simples; destacar pão e proteína principal; não confundir com X-Tudo. |
| X-Salada | Valorizar as camadas de vegetais **que constarem do cadastro**; corte limpo e realista. |
| X-Bacon | Bacon visível na área frontal do sanduíche, em quantidade crível; não copiar o X-Salada. |
| X-Egg | Ovo visível e corretamente posicionado, **somente se integrante da receita base**. |
| X-Tudo | Sanduíche mais completo e volumoso, mas estruturalmente possível; ingredientes conforme cadastro. |
| X-Frango | Frango claramente distinguível da carne bovina; preparo e acompanhamentos fiéis. |
| X-Calabresa | Calabresa reconhecível, grelhada de forma plausível, sem substituir por hambúrguer comum. |
| Batata Frita Pequena | Porção modesta com proporção visual consistente; sem toppings não cadastrados. |
| Batata Frita Grande | Mesma linguagem, maior volume reconhecível; não reutilizar a imagem da pequena. |
| Calabresa Acebolada | Calabresa e cebola preparadas de forma realista; recipiente discreto e coerente. |
| Bebidas disponíveis | Representação correta do recipiente e volume; itens genéricos sem marcas artificiais. Se a fidelidade ao rótulo for essencial, usar placeholder e solicitar foto real. |

**Para cada item:** compor um prompt específico, gerar pelo menos uma alternativa válida, inspecionar o resultado e repetir **somente** os itens com defeitos. Não deixar as sete fotos de lanche praticamente idênticas. Se o modelo aceitar edição/referência visual, fornecer as duas imagens originais junto ao prompt para consistência, respeitando limitações do recurso.

## 4. Formato, nomes e armazenamento

- Fotos do catálogo: proporção **1:1**, idealmente pelo menos **1024 × 1024 px** na geração original; guardar versão otimizada `.webp`, preferencialmente com 768–1024 px de lado. Escolher compressão visualmente boa, buscar ~100–300 KB por item quando possível sem degradação perceptível.
- Guardar exclusivamente as imagens finais aprovadas em `public/images/produtos/` no Next.js. Nome em `kebab-case`: `hamburguer-classico.webp`, `x-salada.webp`, `x-bacon.webp`, `x-egg.webp`, `x-tudo.webp`, `x-frango.webp`, `x-calabresa.webp`, `batata-frita-pequena.webp`, `batata-frita-grande.webp`, `calabresa-acebolada.webp` e equivalentes para bebidas reais.
- Não criar versões JPEG/PNG duplicadas em produção sem necessidade. Não usar imagens base64 gigantes no código, nem URL temporária como fonte persistente.
- Gerar banner 16:9 **somente se houver lugar real para ele no design**; banner deve ser mais amplo e contemplativo, sem texto embutido, e **não** reintroduzir o visual chamativo que foi rejeitado. Se não existir necessidade, não gerar banner.
- Referências visuais originais ficam apenas em `referencias_visuais/fotografia_produtos/`, fora de `public/`; não publicá-las como fotos comerciais. Evitar versionar referências de terceiros, caso haja restrições de uso.

## 5. Integração cuidadosa com o catálogo

1. Localize a implementação atual do cardápio público e as fontes de `imagem_url`. Garanta suporte a URLs `https://...` e caminhos locais `/images/produtos/...`, sem quebrar `next/image`, dimensões ou lazy loading. Se usar `next/image` para hosts externos, configure só hosts necessários; não usar wildcard permissivo sem justificativa.
2. Associe as imagens aos itens DEMO via mapeamento determinístico de slug/código, **sem alterar produtos comerciais existentes**. Se a arquitetura requer atualizar `imagem_url` na API, faça isso **somente se houver autorização prévia para alterar registros demonstrativos identificados**, por endpoint administrativo e com backup/rollback seletivo. **Não escreva diretamente no Neon**, não altere `DATABASE_URL` e nunca substitua imagem preexistente da cliente.
3. Os placeholders devem permanecer úteis quando faltar imagem, falhar o carregamento ou o item não for DEMO. A interface não deve presumir que todo produto possui foto.
4. Mantenha `alt` com o nome real do produto (sem texto promocional artificial); preserve proporção, use `object-fit: cover` e garanta que o produto não fique cortado no card, modal e mobile.
5. **Não alterar regras comerciais**, preços, checkout, categorias, pão/adicionais, CSS globais ou design system só para acomodar fotos. Ajuste de layout para exibição correta é permitido, mas preserve o redesign sóbrio.

## 6. Testes e comprovação visual

1. Checar que todos os arquivos `.webp` estão presentes, abrem corretamente e têm dimensões/peso esperados. Verificar visualmente cada foto: sem ingrediente inventado, sem logotipos falsos, sem repetição indevida, sem artefatos de IA e sem texto embutido.
2. Navegar por `localhost:3000` e verificar GET 200 dos assets sem autenticação; conferir cardápio em **360/390/430/768/1024/1440 px** e a página de detalhe, sem imagens cortadas ou layout quebrado.
3. Validar com Playwright captura antes/depois de ao menos um lanche, uma porção e uma bebida; se o teste usa mocks, identificá-lo como mock — não alegar prova de cadastro real.
4. Rodar `npm run lint`, `npm run typecheck`, `npm run test`, `npm run build` e E2E relevantes, sem sacrificar qualidade para passar testes.
5. Não chamar VAPID, R2, serviços de impressão ou e-mail; não enviar pedido real. Não modificar `.env` ou segredos.

## 7. Documentação obrigatória para acompanhamento

Criar/atualizar `docs/IMAGENS_PRODUTOS.md` com:

- As duas referências estavam realmente acessíveis? Em quais caminhos? O que foi observado em cada uma?
- Qual skill/ferramenta de geração foi usada, versão/modelo se disponível, e quais limitações existiram?
- **Manifesto completo**: produto real, slug/ID se pertinente, ingredientes usados no prompt, arquivo final, resolução, peso, status (GERADO/PLACEHOLDER/PENDENTE), motivo se pendente.
- Prompt final exato usado para **cada** imagem, sem segredos.
- Miniaturas ou contato visual em `docs/screenshots/` e link local para os arquivos finais.
- Arquivos de código alterados, testes realmente executados, imagens rejeitadas e melhorias pendentes.
- Distinção clara: **"Imagem demonstrativa gerada por IA — substituir por foto real antes da divulgação comercial"**, sempre que aplicável.

Atualizar `docs/STATUS_ATUAL.md` e `docs/HANDOFF_CHATGPT.md`, com resumo desta etapa e o que preciso revisar depois. **Não marcar como concluída a geração caso apenas os prompts tenham sido criados.**

## 8. Critérios de aceite

- [ ] Duas referências analisadas de verdade, ou indisponibilidade documentada.
- [ ] Prompts individualizados refletem ingredientes confirmados, sem invenções.
- [ ] Fotos geradas com estilo consistente e visual sóbrio (ou bloqueio honesto se não houver ferramenta).
- [ ] Arquivos finais `.webp` no diretório correto e manifesto de associação.
- [ ] Nenhuma imagem real, produto comercial ou dado sensível sobrescrito.
- [ ] Cardápio público mostra as imagens DEMO corretamente quando há correspondência segura.
- [ ] Responsividade, acessibilidade e testes rodados e documentados.
- [ ] Handoff e documentação atualizados.

**Comece inspeccionando as duas referências e os dados reais do catálogo.** Trabalhe autonomamente dentro das permissões autorizadas. Se houver impedimento para a ferramenta de imagem, não invente evidências: entregue prompts específicos prontos para uma ferramenta de geração e registre a limitação.
