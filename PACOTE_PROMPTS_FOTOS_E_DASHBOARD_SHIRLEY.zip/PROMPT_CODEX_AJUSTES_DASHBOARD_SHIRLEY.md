# Complemento — Ajustes visuais e de usabilidade do dashboard da Lanchonete Shirley

> **Executar no frontend Next.js EXISTENTE.** Continuação dos redesigns anteriores, sem recriar a aplicação e sem alterar contratos, migrations, seeds, `.env` ou dados de produção. A screenshot fornecida pelo usuário `Screenshot_11.png` (tela **Novo pedido manual**) é referência obrigatória para identificar o problema de espaçamento.

## Primeiro: skills e diagnóstico

- Localize e leia, se disponíveis, `frontend-design` e `ui-ux-pro-max`; aplique as regras pertinentes ao design existente. Preserve a identidade sóbria já revisada: fundos neutros, branco, texto escuro, terracota usado só como destaque, mostarda mínima, Lucide React.
- Inspecione `src/app/globals.css`, tokens Tailwind, sidebar/admin shell, status da loja, componente de tabela/listagem, `src/components/ui` e os formulários do painel. Registre os componentes afetados e a causa dos problemas antes de alterá-los.
- Não use hex disperso ou `!important` como correção rápida. Centralize decisões novas em tokens semânticos globais e utilitários compartilhados.

## 1. Cabeçalhos das tabelas administrativos

- Aplicar **um único padrão** em todos os `thead`/header grids realmente tabulares: fundo cinza frio ou quente muito claro, um tom acima do fundo geral (exemplo de referência de contraste: `#EEEFF1` ou token equivalente), texto de cabeçalho grafite, peso 600, divisória inferior suave. Não pintar cabeçalhos de vermelho sólido, amarelo ou dourado.
- Distinção visual clara entre header e linhas; alinhar colunas de header e células usando a **mesma estrutura**, tamanhos mínimos e regras de largura. Evitar deslocamento causado por scrollbar vertical interna.
- Ordenação, seleção, badges, ações, loading e paginação devem permanecer legíveis. Em desktop utilizar tabela sem quebra indevida e, em celular, converter para cards/lista ou scroll horizontal limitado somente à tabela, sem causar overflow da página.
- Aplicar no mínimo às telas de produtos, categorias, usuários, pedidos, relatórios, logs e demais listagens reais do projeto.

## 2. Status 'Loja aberta/fechada' na dashboard

- Redesenhar o indicador de **estado efetivo** com texto inequívoco e sem chips gigantes ou verde/vermelho saturados: ícone pequeno `Store`/`LockKeyhole` ou `Circle`, fundo semântico suave, cor contrastante e legenda contextual.
- **Não confundir** o status efetivo da API (`aberta`, que depende de horários e estado manual) com o controle administrativo `aceitar_pedidos`. Exibir separadamente, quando relevante: `Aberta para pedidos` / `Fechada para pedidos` e `Aceitação manual: permitida/bloqueada` ou explicação `Fora do horário`, se o backend fornecer esse motivo.
- Para abrir/fechar, usar rótulos de ação seguros que descrevam o efeito real (por exemplo `Permitir pedidos no horário`/`Pausar pedidos`), com estado de carregamento e confirmação apropriada. Não declarar aberta quando apenas a flag manual estiver ligada fora do horário.
- As ações só devem aparecer com a permissão correspondente. Não confiar em RBAC visual como substituto da autorização do backend.

## 3. Espaçamento da tela 'Novo pedido manual' — Screenshot_11

- O print demonstra que as opções `Retirada` / `Entrega` ficam **coladas ao rodapé dos inputs** `Nome` / `Telefone`, com bordas quase sobrepostas. Corrigir de modo estrutural, não apenas adicionando margem em uma instância.
- Usar `fieldset`/`legend` semântico para a seleção de modalidade; espaçamento vertical consistente entre grupo de campos e opções de modalidade (referência inicial: `row-gap` de 16–20 px entre grupos; ajustar conforme design system), label acima do input com distância de 6–8 px, margem de 4–6 px entre hint/erro e próximo campo. Bordas jamais devem se tocar. Mensagens de validação não podem empurrar apenas uma coluna e desalinhá-la.
- A primeira linha `Nome` e `Telefone` deve utilizar o mesmo alinhamento e largura conforme grid. Opções `Retirada` e `Entrega` devem ter altura e alinhamento consistentes; em largura pequena, empilhar se necessário para manter alvos de toque de aproximadamente 44–48 px.
- Auditar **todos os formulários administrativos**, em especial configuração da loja, horários, impressão, produtos e usuários, para a mesma classe de desalinhamento quando existe descrição/legenda externa. Corrigir no componente compartilhado ou na estrutura de grid (`gap`, `items-start`, linha reservada de hint quando necessário), e não com offsets mágicos.

## 4. Cor da sidebar administrativa

- A sidebar no desktop deve ser distinguível da área principal por um **fundo neutro discreto** (por exemplo cinza-areia suave `#F3F2F0`), borda direita sutil e espaços internos consistentes. Não usar vermelho chapado nem amarelo forte em toda a sidebar.
- Ativo: faixa/acento terracota pequena, texto escuro em peso 600 e fundo ligeiramente diferenciado; demais itens ficam neutros. Ícones Lucide de tamanho consistente. Respeitar divisórias de grupos e espaçamento, sem poluição visual.
- Desktop: sidebar fixa/estável e conteúdo sem recorte. Android: preservar a navegação inferior, safe-area e estado ativo correspondente, sem forçar uma sidebar estreita em celulares. Navegação e ações visíveis somente conforme permissões já disponíveis.

## 5. Verificações de qualidade

- Playwright ou navegador: verificar screenshots reais **antes e depois** de `Novo pedido manual` em 360×800 e 1024×768; tabela de produtos/categorias em 390×844 e 1440×900; dashboard aberta e fechada (com mocks identificados se não houver estados reais seguros), sidebar e bottom navigation.
- Testar teclado virtual, foco, zoom e 320–1440 px, ausência de overflow, acessibilidade dos radios/labels e contraste WCAG. Certificar-se de que o gap do print foi resolvido em estado normal e com mensagem de validação.
- Rodar lint, typecheck, unit, E2E pertinente e build; preservar todos os testes anteriores. Se algum comando não puder rodar, documentar motivo.
- Atualizar `docs/STATUS_ATUAL.md`, `docs/HANDOFF_CHATGPT.md` e criar `docs/32_AJUSTES_VISUAIS_DASHBOARD.md` com imagens de antes/depois, causa raiz, arquivos alterados e testes.

**Critério de aceite:** cabeçalhos sóbrios e legíveis em todas as tabelas; status da loja correto e compreensível; inputs e radios com gap consistente em todos os tamanhos; sidebar colorida de forma **discreta e profissional**; nenhum fluxo ou permissão quebrado.
